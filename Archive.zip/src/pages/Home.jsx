import CardSwap, { Card } from "../componenets/CardSwap";
import WikiTemplate from "../componenets/WikiTemplate";

export const Home = () => {
  return (
    <>
      <div style={{ height: "800px", position: "center" }}>
        <CardSwap
          cardDistance={60}
          verticalDistance={70}
          delay={3000}
          pauseOnHover={true}
        >
          <Card style={{ border: "8px solid black" }}>
            <WikiTemplate />
          </Card>
          <Card style={{ border: "8px solid black" }}>
            <WikiTemplate />
          </Card>
          <Card style={{ border: "8px solid black" }}>
            <WikiTemplate />
          </Card>
          <Card style={{ border: "8px solid black" }}>
            <WikiTemplate />
          </Card>
        </CardSwap>
      </div>
      <button
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          padding: "10px 20px",
          fontSize: "18px",
          cursor: "pointer",
          borderRadius: "999rem",
        }}
        onClick={() => {
          window.location.href = "/create";
        }}
      >
        Create Your Wiki Now!
      </button>
    </>
  );
};

export default Home;
