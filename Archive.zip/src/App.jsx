import React from "react";
import "./App.css";
import Home from "./pages/Home";
export const App = () => {
  return (
    <>
      <h1>WikiMe</h1>
      <h2>Generate a Wiki in no time<br></br>And Share it with your friends instantly!!</h2>
      <Home />
    </>
  );
};

export default App;
