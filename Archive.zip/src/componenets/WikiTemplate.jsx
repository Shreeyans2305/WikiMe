import React, { useState } from 'react';

// ─── Dummy Data ────────────────────────────────────────────────────────────────
const PAGE_DATA = {
  name: 'Socrates',
  subtitle: 'The Ancient Greek Philosopher',
  imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Socrates.png/250px-Socrates.png',
  imageCaption: 'Bust of Socrates, Roman copy after a Greek original',
  born: '470 BC, Alopeke, Athens',
  died: '399 BC (aged ~71), Athens',
  occupation: 'Philosopher',
  spouse: 'Xanthippe',
  children: ['Lamprocles', 'Sophroniscus', 'Menexenus'],
  nationality: 'Greek',
  lead: `Socrates (470–399 BC) was a classical Greek philosopher credited as one of
    the founders of Western philosophy. He is known for the Socratic method, a form
    of cooperative argumentative dialogue that stimulates critical thinking. Unlike
    his contemporaries, he left no written works; his ideas are known through the
    writings of his students, particularly Plato.`,
  sections: {
    earlyLife: `Born in Alopeke, a deme of Athens, Socrates was the son of Sophroniscus, a
      stonemason, and Phaenarete, a midwife. Little is known about his early education,
      though he was likely taught reading, writing, and the traditional curriculum of music
      and gymnastics. As a young man he served as an infantryman during the Peloponnesian
      War, distinguishing himself at the battles of Potidaea, Delium, and Amphipolis.`,
    marriageAndChildren: `Socrates married Xanthippe, who bore him three sons: Lamprocles,
      Sophroniscus, and Menexenus. Ancient sources characterise Xanthippe as strong-willed;
      Xenophon records her as quarrelsome, while other accounts suggest she was simply tested
      by her husband's public life and general indifference to household income.`,
    death: `In 399 BC, Socrates was tried before a jury of 500 Athenian citizens on charges
      of impiety and corrupting the youth. Found guilty by a narrow margin, he was sentenced
      to death by hemlock poisoning. He refused an opportunity to escape arranged by his
      friends, maintaining that a just man must accept the judgement of the laws of his city.
      His final hours are recorded in Plato's Phaedo.`,
    philosophy: `Socrates held that virtue is knowledge and that wrongdoing arises from
      ignorance. He practised what later became known as the Socratic method — a series of
      questions designed to expose the contradictions in an interlocutor's beliefs. He
      claimed to possess no wisdom himself, famously asserting that the only thing he knew
      was that he knew nothing.`,
    publishedWorks: `Socrates wrote nothing. His philosophy survives through the dialogues of
      Plato (e.g., the Republic, the Apology, the Phaedo) and the memoirs of Xenophon
      (Memorabilia, Symposium, Apology). Aristophanes also depicted him, less charitably,
      in the comedy The Clouds (423 BC).`,
    recognition: `Socrates was posthumously recognised as the founding figure of Western
      moral philosophy. The Oracle at Delphi reportedly declared him the wisest of men.
      His trial and execution became a defining episode in the history of intellectual
      freedom and civil disobedience.`,
  },
  references: [
    { id: 1, text: 'Plato. Apology. Translated by G.M.A. Grube. Indianapolis: Hackett, 1981.' },
    { id: 2, text: 'Xenophon. Memorabilia. Translated by Amy Bonnette. Ithaca: Cornell University Press, 1994.' },
    { id: 3, text: 'Vlastos, Gregory. Socrates: Ironist and Moral Philosopher. Cambridge University Press, 1991.' },
  ],
  seeAlso: ['Plato', 'Aristotle', 'Pre-Socratic philosophy', 'Socratic method', 'Ancient Greek philosophy'],
  externalLinks: [
    { label: 'Stanford Encyclopedia of Philosophy – Socrates', href: 'https://plato.stanford.edu/entries/socrates/' },
    { label: 'Internet Encyclopedia of Philosophy – Socrates', href: 'https://iep.utm.edu/socrates/' },
  ],
  categories: ['Ancient Greek philosophers', 'Classical Athens', '470 BC births', '399 BC deaths'],
  lastEdited: 'March 15, 2026',
};

// ─── Sub-components ────────────────────────────────────────────────────────────

function InfoBox({ data }) {
  return (
    <table className="infobox biography vcard" style={styles.infobox}>
      <tbody>
        <tr>
          <th colSpan={2} className="infobox-above" style={styles.infoboxAbove}>
            <div className="fn">{data.name}</div>
          </th>
        </tr>
        <tr>
          <td colSpan={2} className="infobox-image" style={{ textAlign: 'center', padding: '8px' }}>
            <img
              src={data.imageUrl}
              alt={data.name}
              width={200}
              style={{ maxWidth: '100%' }}
            />
            <div style={styles.infoboxCaption}>{data.imageCaption}</div>
          </td>
        </tr>
        {[
          ['Born', data.born],
          ['Died', data.died],
          ['Occupation', data.occupation],
          ['Nationality', data.nationality],
          ['Spouse', data.spouse],
        ].map(([label, value]) => (
          <tr key={label}>
            <th scope="row" className="infobox-label" style={styles.infoboxLabel}>{label}</th>
            <td className="infobox-data" style={styles.infoboxData}>{value}</td>
          </tr>
        ))}
        <tr>
          <th scope="row" className="infobox-label" style={styles.infoboxLabel}>Children</th>
          <td className="infobox-data" style={styles.infoboxData}>
            {data.children.join(', ')}
          </td>
        </tr>
      </tbody>
    </table>
  );
}

function SectionHeading({ id, level = 2, children }) {
  const Tag = `h${level}`;
  return (
    <div className={`mw-heading mw-heading${level}`} style={styles.headingWrapper}>
      <Tag id={id} style={level === 2 ? styles.h2 : styles.h3}>{children}</Tag>
    </div>
  );
}

function TableOfContents({ sections }) {
  return (
    <div style={styles.toc}>
      <div style={styles.tocTitle}>Contents</div>
      <ol style={styles.tocList}>
        {sections.map((s, i) => (
          <li key={s.id} style={styles.tocItem}>
            <a href={`#${s.id}`} style={styles.tocLink}>
              <span style={styles.tocNumber}>{i + 1}</span> {s.label}
            </a>
          </li>
        ))}
      </ol>
    </div>
  );
}

function Toolbar({ lastEdited }) {
  return (
    <div style={styles.toolbar}>
      <nav style={styles.toolbarNav}>
        {['Read', 'Edit', 'View history'].map((tab) => (
          <button key={tab} style={styles.toolbarTab}>{tab}</button>
        ))}
      </nav>
      <span style={styles.lastEdited}>Last edited: {lastEdited}</span>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────

const tocSections = [
  { id: 'Biography', label: 'Biography' },
  { id: 'Early_life', label: 'Early life' },
  { id: 'Marriage_and_children', label: 'Marriage and children' },
  { id: 'Death', label: 'Death' },
  { id: 'Philosophical_views', label: 'Philosophical views' },
  { id: 'Published_works', label: 'Published works' },
  { id: 'Recognition', label: 'Recognition' },
  { id: 'See_also', label: 'See also' },
  { id: 'References', label: 'References' },
  { id: 'Further_reading', label: 'Further reading' },
  { id: 'External_links', label: 'External links' },
];

const WikiTemplate = () => {
  const [activeTab, setActiveTab] = useState('Read');
  const d = PAGE_DATA;

  return (
    <div style={styles.pageWrapper}>
      {/* ── Header ── */}
      <header style={styles.pageHeader}>
        <h1 style={styles.pageTitle}>
          <span style={styles.pageTitleMain}>{d.name}</span>
        </h1>
        <Toolbar lastEdited={d.lastEdited} />
      </header>

      {/* ── Body ── */}
      <div style={styles.bodyContent}>
        {/* Hatnote */}
        <div role="note" style={styles.hatnote}>
          For other uses, see <a href="#" style={styles.link}>{d.name} (disambiguation)</a>.
        </div>

        {/* Lead section — infobox floats right */}
        <div style={styles.leadSection}>
          <InfoBox data={d} />
          <p style={styles.leadText}>
            <strong>{d.name}</strong> {d.lead}
          </p>
        </div>

        
      </div>
    </div>
  );
};

// ─── Inline styles (no external CSS dependency) ────────────────────────────────

const styles = {
  pageWrapper: {
    fontFamily: 'Linux Libertine, Georgia, Times, serif',
    fontSize: '14px',
    lineHeight: '1.6',
    color: '#202122',
    backgroundColor: '#fff',
    maxWidth: '960px',
    margin: '0 auto',
    padding: '0 16px',
  },
  pageHeader: {
    borderBottom: '1px solid #a2a9b1',
    paddingBottom: '4px',
    marginBottom: '8px',
  },
  pageTitle: {
    fontFamily: 'Linux Libertine, Georgia, Times, serif',
    fontSize: '28px',
    fontWeight: 'normal',
    borderBottom: 'none',
    margin: '0 0 4px 0',
    padding: 0,
  },
  pageTitleMain: {
    color: '#000',
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    fontSize: '13px',
    color: '#54595d',
    borderTop: '1px solid #a2a9b1',
    paddingTop: '4px',
  },
  toolbarNav: {
    display: 'flex',
    gap: '8px',
  },
  toolbarTab: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    color: '#0645ad',
    fontSize: '13px',
    padding: '2px 6px',
    fontFamily: 'inherit',
  },
  lastEdited: {
    fontSize: '12px',
    color: '#72777d',
  },
  bodyContent: {
    padding: '8px 0',
  },
  hatnote: {
    fontStyle: 'italic',
    paddingLeft: '1.6em',
    marginBottom: '0.5em',
    color: '#54595d',
  },
  leadSection: {
    overflow: 'hidden',
  },
  infobox: {
    float: 'right',
    clear: 'right',
    margin: '0 0 16px 24px',
    padding: '4px',
    border: '1px solid #a2a9b1',
    backgroundColor: '#f8f9fa',
    fontSize: '88%',
    lineHeight: '1.5em',
    width: '22em',
    borderCollapse: 'collapse',
  },
  infoboxAbove: {
    textAlign: 'center',
    fontSize: '125%',
    fontWeight: 'bold',
    backgroundColor: '#cee0f2',
    padding: '8px',
  },
  infoboxCaption: {
    textAlign: 'center',
    fontSize: '88%',
    color: '#54595d',
    marginTop: '4px',
  },
  infoboxLabel: {
    verticalAlign: 'top',
    textAlign: 'right',
    fontWeight: 'bold',
    padding: '4px 8px',
    whiteSpace: 'nowrap',
    width: '40%',
  },
  infoboxData: {
    verticalAlign: 'top',
    padding: '4px 8px',
  },
  toc: {
    display: 'inline-block',
    border: '1px solid #a2a9b1',
    backgroundColor: '#f8f9fa',
    padding: '12px 20px',
    marginBottom: '16px',
    minWidth: '200px',
  },
  tocTitle: {
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: '8px',
  },
  tocList: {
    margin: 0,
    padding: '0 0 0 20px',
  },
  tocItem: {
    marginBottom: '4px',
    fontSize: '13px',
  },
  tocLink: {
    color: '#0645ad',
    textDecoration: 'none',
  },
  tocNumber: {
    color: '#54595d',
    marginRight: '4px',
  },
  headingWrapper: {
    borderBottom: '1px solid #a2a9b1',
    marginBottom: '4px',
    marginTop: '16px',
  },
  h2: {
    fontFamily: 'Linux Libertine, Georgia, Times, serif',
    fontSize: '22px',
    fontWeight: 'normal',
    margin: '0 0 4px 0',
    padding: 0,
    borderBottom: 'none',
  },
  h3: {
    fontFamily: 'Linux Libertine, Georgia, Times, serif',
    fontSize: '17px',
    fontWeight: 'bold',
    margin: '14px 0 4px 0',
    padding: 0,
  },
  leadText: {
    margin: '0 0 12px 0',
    lineHeight: '1.7',
  },
  p: {
    margin: '8px 0',
    lineHeight: '1.7',
  },
  ul: {
    paddingLeft: '24px',
    margin: '8px 0',
  },
  li: {
    marginBottom: '4px',
  },
  link: {
    color: '#0645ad',
    textDecoration: 'none',
  },
  sup: {
    fontSize: '11px',
  },
  refList: {
    paddingLeft: '28px',
    fontSize: '13px',
    lineHeight: '1.6',
  },
  refItem: {
    marginBottom: '6px',
  },
  catLinks: {
    borderTop: '1px solid #a2a9b1',
    padding: '8px 0',
    marginTop: '24px',
    fontSize: '13px',
  },
  printFooter: {
    fontSize: '12px',
    color: '#54595d',
    marginTop: '12px',
    paddingTop: '8px',
    borderTop: '1px solid #eaecf0',
  },
};

export default WikiTemplate;