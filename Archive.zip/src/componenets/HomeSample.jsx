import React from 'react'
import './HomeSample.css'
export const HomeSample = () => {
  return (
    <div>HomeSample</div>
  )
}
export default HomeSample